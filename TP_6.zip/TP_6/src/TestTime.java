
public class TestTime {

	public static void main(String[] args) {
		GetDateDifference d = new GetDateDifference();
		
		StdOut.println(d.getDate_Time());

	}

}
