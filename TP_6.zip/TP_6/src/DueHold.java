/**
 * @author maya5348
 *
 */
public enum DueHold {
	DAMAGED,OVERDUE,LOST;

}
